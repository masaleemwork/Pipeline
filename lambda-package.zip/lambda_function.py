import boto3
import json
import yaml
import logging

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

sc = boto3.client('servicecatalog')
s3 = boto3.client('s3')
ssm = boto3.client('ssm')
def get_or_create_portfolio(portfolio_name, provider):
    response3 = sc.list_portfolios()
    existing_portfolios = response3['PortfolioDetails']


    # initialize a flag to check if portfolio exists
    portfolio_exists = False
    portfolio_id = None
    
    # check if the portfolio exists already
    for portfolio in existing_portfolios:
        if portfolio['DisplayName'] == portfolio_name:
            portfolio_exists = True
            portfolio_id = portfolio['Id']
            break
    
    # if not, create a new one
    if not portfolio_exists:
        portfolio_id = sc.create_portfolio(
            DisplayName=portfolio_name,
            ProviderName=provider
        )['PortfolioDetail']['Id']
    
    return portfolio_id

def lambda_handler(event, context):
    logger.info('Event: %s', event)
    codepipeline_client = boto3.client('codepipeline')
            
    try:
        # Get input artifacts bucket
        job_id = event['CodePipeline.job']['id']
        input_artifacts = event['CodePipeline.job']['data']['inputArtifacts']
        input_artifact = input_artifacts[0]
        s3_bucket = input_artifact['location']['s3Location']['bucketName']
        
        # Get input artifacts from bucket
        response = s3.list_objects_v2(Bucket=s3_bucket)
        desired_file_extension = '.tar.gz'
        desired_file = next(
            (file for file in response['Contents'] if file['Key'].endswith(desired_file_extension)),
            None
        )
        object_url = f"https://{s3_bucket}.s3.amazonaws.com/{desired_file['Key']}"
        desired_file_extension2 = '.yml'
        desired_file2 = next(
            (file for file in response['Contents'] if file['Key'].endswith(desired_file_extension2)),
            None
        )

        # Load and retrieve information from mapping yml file
        response2 = s3.get_object(Bucket=s3_bucket, Key=desired_file2['Key'])
        mapping_content = response2['Body'].read().decode('utf-8')
        mapping = yaml.safe_load(mapping_content)

        products = mapping.get('products', [])
        for product_info in products:
            product_name = product_info.get('name', '')
            description = product_info.get('description', '')
            distributor = product_info.get('distributor', '')
            portfolio_name = product_info.get('portfolio', {}).get('name', '')
            provider = product_info.get('portfolio', {}).get('provider', '')
            support_description = product_info.get('support', {}).get('description', '')
            owner = product_info.get('owner', '')
            support_description = product_info.get('support', {}).get('description', '')
            support_email = product_info.get('support', {}).get('email', '')
            support_url = product_info.get('support', {}).get('url', '')
            user_arn = product_info.get('user', {}).get('arn', '')
            provisioning_name = product_info.get('provisioning', {}).get('name', '')
            provisioning_description = product_info.get('provisioning', {}).get('description', '')
            launch_role = product_info.get('user', {}).get('role', '')

        # Get or create the portfolio
        portfolio_id = get_or_create_portfolio(portfolio_name, provider)

        # Searching for products within the portfolio
        response = sc.search_products_as_admin(
            PortfolioId=portfolio_id,
            Filters={
                'FullTextSearch': [product_name]
            }
        )
        
        # If product exists, update it
        if response['ProductViewDetails']:
            for product in response['ProductViewDetails']:
            # Updating existing product
                response = sc.update_product(
                    Id=product['ProductViewSummary']['ProductId'],
                    Name=product_name,
                    Owner=owner,
                    Description=description,
                    Distributor=distributor,
                    SupportDescription=support_description,
                    SupportEmail=support_email,
                    SupportUrl=support_url,
                    AddTags=[
                    {
                        'Key': 'Testproduct',
                        'Value': 'Product1'
                    }
                ]
                )
                product_id = response['ProductViewDetail']['ProductViewSummary']['ProductId']

                response = sc.list_provisioning_artifacts(
                    ProductId=product_id
                )

                new_version = True

                for version in response['ProvisioningArtifactDetails']:
                    if version['Name'] == provisioning_name:
                        new_version = False
                        break

                if(new_version):
                    response = sc.create_provisioning_artifact(
                        ProductId=product_id,
                        Parameters={
                            'Name': provisioning_name,
                            'Description': provisioning_description,
                            'Info': {
                                'LoadTemplateFromURL': object_url
                            },
                            'Type': 'TERRAFORM_OPEN_SOURCE',
                            'DisableTemplateValidation': True
                        }
                    )

                # Updating constraints
                response = sc.list_constraints_for_portfolio(
                    PortfolioId=portfolio_id,
                    ProductId=product_id
                ) 
                for constraint in response['ConstraintDetails']:
                    sc.update_constraint(
                        Id=constraint['ConstraintId'],
                        Parameters=f'{{ "LocalRoleName": "{launch_role}" }}'
                    )

                sc.associate_principal_with_portfolio( 
                    PortfolioId=portfolio_id,
                    PrincipalARN=user_arn,
                    PrincipalType='IAM'
                )
        # if product doesn't exist, create a new product
        else:
            response = sc.create_product(
                Name=product_name,
                Owner=owner,
                Description=description,
                Distributor=distributor,
                SupportDescription=support_description,
                SupportEmail=support_email,
                SupportUrl=support_url,
                ProductType='TERRAFORM_OPEN_SOURCE',
                Tags=[
                    {
                        'Key': 'Testproduct',
                        'Value': 'Product1'
                    }
                ],
                ProvisioningArtifactParameters={
                    'Name': provisioning_name,
                    'Description': provisioning_description,
                    'DisableTemplateValidation': True,
                    'Info': {
                        'LoadTemplateFromURL': object_url
                    },
                    'Type': 'TERRAFORM_OPEN_SOURCE'
                }
            )
            
            # Returning product id
            product_id = response['ProductViewDetail']['ProductViewSummary']['ProductId']

            # Assigning the product to the portfolio
            sc.associate_product_with_portfolio(
                ProductId=product_id,
                PortfolioId=portfolio_id
            )

            # Assigning prinicpals/users to the portfolio
            sc.associate_principal_with_portfolio( 
                PortfolioId=portfolio_id,
                PrincipalARN=user_arn,
                PrincipalType='IAM'
            )

            # Creating launch constrains
            sc.create_constraint(
                PortfolioId=portfolio_id,
                ProductId=product_id,
                Parameters=f'{{ "LocalRoleName": "{launch_role}" }}',
                Type='LAUNCH'
            )
        
        ssm.put_parameter(
            Name=f'/ServiceCatalog/Products/{product_name}',
            Description="Product Id",
            Value=product_id,
            Type="String"
        )
        # Signal a success to CodePipeline
        codepipeline_client.put_job_success_result(jobId=job_id)

    except Exception as e:
        print(f"Error occurred: {str(e)}")
        # Signal a failure to CodePipeline
        codepipeline_client.put_job_failure_result(
            jobId=job_id,
            failureDetails={'message': str(e), 'type': 'JobFailed'}
        )
        return {
            'statusCode': 500,
            'body': json.dumps('Lambda execution failed!')
        }
    # Signal success
    return {
        'statusCode': 200,
        'body': json.dumps('Lambda execution completed!')
    }

